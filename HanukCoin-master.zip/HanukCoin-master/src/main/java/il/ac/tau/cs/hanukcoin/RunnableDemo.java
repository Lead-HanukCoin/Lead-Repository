package il.ac.tau.cs.hanukcoin;

public class RunnableDemo implements Runnable {
    public void run(){
        System.out.println("shahaf");
    }
}
